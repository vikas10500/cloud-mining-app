
import React from 'react';

const App = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>Welcome to Cloud Mining</h1>
      <p>This is a basic React app deployed to Vercel using Vite.</p>
    </div>
  );
};

export default App;
